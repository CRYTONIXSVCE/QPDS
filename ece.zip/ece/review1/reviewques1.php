<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                 <a class="navbar-brand">Galgotias University</a>
            </div>
            <!-- /.navbar-header -->

            
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">
                                        <i class="fa fa-search"></i>
                                    </button>
                                </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        
                         <li>
                            <a href="bala.php"></i> Review Question</a>
                        </li>
						 <li>
                            <a href="viewsyllabus.php"> View Syllabus</a>
                        </li>
                       
                       
                        <li class="active">
                            <a href="#"> Sample Pages<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a class="active" href="blank.html">Blank Page</a>
                                </li>
                                <li>
                                    <a href="login.html">Login Page</a>
                                </li>
                            </ul>
							<li>
                            <a href="logout.php"></i>Logout</a>
                        </li>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

                        
                            
                       
                                     
             

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header" align="center">List of Questions</h1>
						
						<?php include('connect.php');
						?>
<html>
<head>
<title> all Articles </title>
<script src="ckeditor/ckeditor.js"></script>
</head>
 <style type="text/css">
    body
  {
    font-family: sans-serif;
    position: absolute;
        margin: 0px;
        width: 100%;
  }
  table
{
width: 70%;
      
}
    table,td
    {
      border: 2px solid black;
      border-collapse:collapse;
    }
    .header
    {
      background-color:green;
      color: white;
	  text-align: center;
    }
    #content
    {
      font-size: 18px;text-align: center;
    }
    #submit
    {
      margin-left:620px;
    }
   
  
    .container
        {
            width: 480px;
            height:20px;
            border:1px solid black;
            margin-left: 35%;
            margin-top: 10%; 
            background-color:#f0f0f0;
            position: absolute;
			
        }
        .message
        {
            position: absolute;
            margin-left:10px;
            font-size:18px;
            margin-top: 50px;
			text-align: center;
        }
      
        
        #text
    {
        height: 45px;
        width: 53px;
        border:2px solid;
        border-color:solid black;
        border-top-style: 1px;
        border-left-style:  1px;
        border-right-style:  none;
        font-size:15px;
		text-align: center;
    }

  </style>


	


<body>
<table  align="center">
<?php
include 'db.php';
if (isset($_POST['activate'])||isset($_POST['deactivate'])) {
	# code...
if(isset($_POST['checkbox'])){
	$checkbox = $_POST['checkbox'];
if(isset($_POST['activate'])?$activate = $_POST["activate"]:$deactivate = $_POST["deactivate"])
$question_number = "('" . implode( "','", $checkbox ) . "');" ;
	$query2="UPDATE question_master2 SET r1 = '".(isset($activate)?'Y':'N')."' WHERE question_number IN $question_number";
	$result2=mysql_query($query2);
	exit();
 }
} 

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset="utf-8"" />
<title>Update multiple rows in mysql with checkbox</title>

<script type="text/javascript">

</script>

</head>
<body>

<table width="400" border="0" cellspacing="1" cellpadding="0">
<tr>
<td><form name="frmactive" method="post" action="">
<table width="400" border="0" cellpadding="3" cellspacing="1">
<tr>
<td colspan="5"><input name="activate" type="submit" id="activate" value="Activate" />
<input name="deactivate" type="submit" id="deactivate" value="Deactivate" /></td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="4"><strong>Update multiple rows in mysql with checkbox</strong> </td>
</tr><tr>

<td align="center"><strong>Question Number</strong></td>
<td align="center"><strong>Course Code</strong></td>
<td align="center"><strong>Question</strong></td>
<td align="center"><strong>Status</strong></td>
<td align="center"><input type="checkbox" name="allbox" title="Select or Deselct ALL" style="background-color:#ccc;"/></td>
</tr>
<?php
if(isset($_POST['submit'])){
$course_code=$_POST['course_code'];
$query="SELECT question_number,course_code,question FROM question_master2 WHERE course_code='$course_code'";
$result=mysql_query($query,$link);
echo mysql_errno($link) . ": " . mysql_error($link). "\n";
}
else{
	header("Location:/qpds/admin/reviewer1.php");
}
while($rows=mysql_fetch_array($result)){
?>
<tr>

<td id="text"><?php echo $rows['question_number']; ?></td>
<td id="text"><?php echo $rows['course_code']; ?></td>
<td id="text"><?php echo $rows['question']; ?></td>
<td id="text"><? echo $rows['r1']; ?></td>
<td id="text"><input name="checkbox[]" type="checkbox" id="checkbox[]" value="<?php echo $rows['question_number']; ?>"></td>

</tr>
<?php
}
?>
<tr>
<td colspan="5" align="center">&nbsp;</td>
</tr>
</table>
</form>
</td>
</tr>
</table>
</body>
</html>

</div>
<div>

</div>

                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
