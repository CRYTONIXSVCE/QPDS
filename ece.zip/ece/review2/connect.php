<?php $con=mysqli_connect('localhost','root','','scv') or die("ERROR");
?>