<?php 

if(!isset($_SERVER['HTTP_REFERER']))
{
	header('location:index.php');
	exit;
}


?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">SVCS,Bengaluru</a>
            </div>
            <!-- /.navbar-header -->

            
            <!-- /.navbar-top-links -->

            
           
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        
                        
                        <li class="active">
                            <a href="#"> Question Paper Generation<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                            <li>
                                    <a class="active" href="quesstep1.php">Reviewed Questions</a>
                                </li>
                                <li>
                                    <a class="active" href="createqp.php">Add Questions</a>
                                </li>
                                <li>
                                    <a href="hot.php">Generate Question Paper</a>
                                </li>
                                <li>
                                    <a href="qpupload.php">Question Paper Upload</a>
                                </li>
                            </ul>
                            <li>
                            <a href="viewqp.php"></i>Print  Question Paper</a>
                        </li>
                        <li>
                            <a href="Backup.php"></i>Backup</a>
                        </li>
                            <li>
                            <a href="logout.php"></i>Logout</a>
                        </li>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
                              
                           
                        

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
					
					
    <form class="form"  method="post" enctype="multipart/form-data" autocomplete="off">
      <div class="alert alert-error"></div>
					
					<h1 class="page-header">Question Paper  Upload</h1>
						
                                           <div class="form-group">
                                            <label>Select the Course Code</label>
											<select class="form-control" name="course_code" required="">
                                           	<option value="">Select the Course Code</option>		

                                              <?php 
                                            include 'db.php';
                                            $query="SELECT * FROM coursemaster";
                                            $result=mysql_query($query);
                                            while($obtained=mysql_fetch_array($result))
                                               {
                                                   $course_code=$obtained['course_code'];
                                                   echo"<option value='$course_code'>$course_code</option>";
                                               } 
                                               ?>
                                            </select>
                                        </div>

      <div class="avatar" required=""><label>Select your File: </label><input type="file" name="avatar" accept=".pdf" required /></div>
	  <br>
	  <div>
      <input type="submit" value="Submit" name="register" class="btn btn-block btn-primary" /><div>
	
</form>
  </div>
</div>
	
<?php $mysqli = new mysqli("localhost", "root", "", "ckeditor");
 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    //two passwords are equal to each other
   //define other variables with submitted values from $_POST
        $course_code = $_POST['course_code'];
       // $course_title = $_POST['course_title'];

    
       

        //path were our avatar image will be stored
        $avatar_path = $mysqli->real_escape_string('qpupload/'.$_FILES['avatar']['name']);
        //make sure the file type is image
        if (preg_match("!pdf!",$_FILES['avatar']['type'])) {
            
            //copy image to images/ folder 
            if (copy($_FILES['avatar']['tmp_name'], $avatar_path)){
                
                //set session variables to display on welcome page
               // $_SESSION['course_code1'] = $course_code1;
                //$_SESSION['avatar'] = $avatar_path;

                //insert user data into database
                $sql = 
                "INSERT INTO qpupload(course_code,avatar) "
                . "VALUES ('$course_code', '$avatar_path')";
                 echo "<script> alert('Data Stored Successfully');</script>";
                //check if mysql query is successful
                if ($mysqli->query($sql) === true){
                    $_SESSION['message'] = "Registration successful!"
                    . "Added $course_code to the database!";
                    //redirect the user to welcome.php
                    //header("location: welcome.php");
                }
            }
		}
        
    }

?>             
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>



