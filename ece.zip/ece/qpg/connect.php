<?php $con=mysqli_connect('localhost','root','','ccse') or die("ERROR");
?>