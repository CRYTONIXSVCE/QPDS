<style type="text/css">
    body
  {
    font-family: Times New Roman;
   
    position: absolute;
        margin: 0px;
        width: 100%;
  }
  {
 font-size: 40px;

  }
  
  table
{
width: 90%;
      
}
 
  
   
     
      
        
        #text2
    {
        height: 55px;
        width: 853px;
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: opx;
        border-left-style:  1px;
        border-right-style:  1px;
        font-size:12px;
         margin-top: :0;
      
		text-align: left;
    }
	      #text1
    {
        height: 85px;
        width: 587px;
       
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: 1px;
        border-left-style:  1px;
        border-right-style:  1px;
        font-size:12px;
       
		text-align: left;
    }
	
  
  </style>

<?php
include ('db.php');
if(isset($_POST['submit'])){
$selected_val = $_POST['scn'];  // Storing Selected Value In Variable
$selected_val1 = $_POST['exam']; 
$selected_val2 = $_POST['monthyear'];  // Storing Selected Value In Variable
$selected_val3 = $_POST['sem'];; 
$selected_val4= $_POST['programme'];// Storing Selected Value In Variable
$selected_val5 = $_POST['semester'];
$selected_val6= $_POST['course_title'];// Storing Selected Value In Variable
$selected_val7 = $_POST['marks'];
$selected_val8= $_POST['course_code']; // Storing Selected Value In Variable
$selected_val9 = $_POST['exam']; 

   // Displaying Selected Value

}
?>
 





<?php
	include 'db.php';
	$pageTitle = "View Question Paper";
		?>
	<style>
	@page { margin: 2cm 2cm 2cm 2cm; } 
	</style>
	
	<div>
	
	<tr>
	<td><b>Name : ................................................</b></td>
	
	</tr><br><br>
	<tr>

	<td><b>Student Admn. No : ............................</b></td>
	</tr>
	
	</div>
	
	<br><br>
	<div id="qp-content">
	<div align="center">
	<b> 
	<?php

include ('db.php');
if(isset($_POST['submit'])){
$selected_val = $_POST['scn'];  
echo "<tr'>
            <td>$selected_val</td>
            
			
			 
            
        </tr>";
}
?></b>
<br>
<b>
	<?php

include ('db.php');
if(isset($_POST['submit'])){
$selected_val1 = $_POST['exam'];  
echo "<tr'>
            <td>$selected_val1</td>
            
			
			
            
        </tr>";
}?>,  <?php

include ('db.php');
if(isset($_POST['submit'])){
$selected_val2 = $_POST['monthyear'];  
echo "<tr'>
            <td>$selected_val2</td>
            
			
			
            
        </tr>";
}?> Semester:  <?php

include ('db.php');
if(isset($_POST['submit'])){
$selected_val2 = $_POST['sem'];  
echo "<tr'>
            <td>$selected_val2</td>
            
			
			
            
        </tr>";
}?></b><br>
[Programme :	  <?php

include ('db.php');
if(isset($_POST['submit'])){
$selected_val4 = $_POST['programme'];  
echo "<tr'>
            <td>$selected_val4</td>
            
			
			
            
        </tr>";
}?>] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[Semester:
 <?php

include ('db.php');
if(isset($_POST['submit'])){
$selected_val5 = $_POST['semester'];  
echo "<tr'>
            <td>$selected_val5</td>
            
			
			
            
        </tr>";
}?>]<br><br>

  
  
  <table>
	<tr>
	
	<td><b>Course Code:
  	  <?php

include ('db.php');
if(isset($_POST['submit'])){
$selected_val8 = $_POST['course_code'];  
echo "<tr'>
            <td>$selected_val8</td>
           			
            
        </tr>";
}?></b> 
</td>
<td width="30%">
	
	
	<b>Course Title :
    <?php

include ('db.php');
if(isset($_POST['submit'])){
$selected_val6 = $_POST['course_title'];  
echo "<tr'>
            <td>$selected_val6</td>
            			 
        </tr>";
}?></b>
	
	<td width="30%"><b>Time : </b></td>
	<td>1.30 Hrs</td>
	</td>
	
</tr>
<tr>
	
	
	
	
	<td><b>
Max Marks :
<b>
  <?php

include ('db.php');
if(isset($_POST['submit'])){
$selected_val8 = $_POST['marks'];  
echo "<tr'>
            <td>$selected_val7</td>
           			
            
        </tr>";
}?></b>



</td>
	
	</tr>
	</table>	
  	
 <div class="bodyc">
<br>
 <div id="container">


    <table  align="center" >
	<tr>
		<td valign="top">
	<b>Instructions:</b></td> <td colspan="15" valign="top"><?php
$fromtextarea=$_POST['text'];
echo $fromtextarea;


	 ?></td>
	</tr>
	<tr><td align="center" colspan="5"> <b>Group A (4X5=20 Marks)<br>
All Questions are Compulsory 
</b></td></tr>
   <tr>


<td class="header"><br><br><b><span id="content">S.No</span></b></td>
<td class="header"><br><br><b><span id="content">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Question</span></b></td>	
<td class="header"><br><br><b><span id="content">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Marks</span></b></td>
<td class="header"><br><br><b><span id="content">CO(s)</span></b></td>
<td class="header"><br><br><b><span id="content">KL(s)</span></b></td>



</tr>
 
   
    
	
	<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 $marks=$_POST['marks'];
	 $r1='X';
	//////////$getco=$_POST['co'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND ete='$r1' and  marks=5";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>
 
<tr>

<td class="text1" valign="top"><?php echo $i;?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>
<td class="text1" valign="top"><?php echo $rows['co'];

 ?></td>
<td class="text1" valign="top"><?php echo $rows['kl']; ?></td>



</tr> 
<?php
}

?>
<tr><td align="center" colspan="5"> <b>Group B (5X10=50 Marks)<br>All Questions are Compulsory
</b></td></tr>

<?php

if(isset($_POST['course_code']))
{
	$i=4;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 $marks=$_POST['marks'];
	 $r1='X';
	//////////$getco=$_POST['co'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND ete='$r1' and  marks=10";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>
 
<tr>

<td class="text1" valign="top"><?php echo $i;?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>
<td class="text1" valign="top"><?php echo $rows['co'];

 ?></td>
<td class="text1" valign="top"><?php echo $rows['kl']; ?></td>



</tr> 
<?php
}

?>
<tr><td align="center" colspan="5"> <b>Group C (2X15=30 Marks)</b></td></tr>

<?php

if(isset($_POST['course_code']))
{
	$i=9;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 $marks=$_POST['marks'];
	 $r1='X';
	//////////$getco=$_POST['co'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND ete='$r1' and  marks=15";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>
 
<tr>

<td class="text1" valign="top"><?php echo $i;?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>
<td class="text1" valign="top"><?php echo $rows['co'];

 ?></td>
<td class="text1" valign="top"><?php echo $rows['kl']; ?></td>



</tr> 
<?php
}

?>




   


</form>
</tbody>
</table>
</div>
<div id="editor"></div>

<!--Add External Libraries - JQuery and jspdf 
check out url - https://scotch.io/@nagasaiaytha/generate-pdf-from-html-using-jquery-and-jspdf
-->
<script src="https://code.jquery.com/jquery-1.12.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
  
  

    <script  src="js/index.js"></script>




</body>

</html>
		

	
	</div>
	
	
		
