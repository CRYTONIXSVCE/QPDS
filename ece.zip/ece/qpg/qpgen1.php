<!DOCTYPE html>
<html lang="en">
<?php include 'db.php'; ?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                 <a class="navbar-brand">SVCS,Bengaluru</a>
            </div>
            <!-- /.navbar-header -->

            
            <!-- /.navbar-top-links -->

                   
                   <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        
                        
                       
                        <li class="active">
                            <a href="#"> Question Generation 80 Marks<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                            <li>
                                    <a class="active" href="quesstep1.php">Reviewed Questions</a>
                                </li>
                                <li>
                                    <a class="active" href="createqp.php">Add Questions</a>
                                </li>
                                 <li>
                                    <a href="hot6.php">Generate Question Paper - VI</a>
                                     <a href="hot7.php">Generate Question Paper - VII</a>
                                     <a href="hot8.php">Generate Question Paper - VIII</a>
                                     <a href="hot9.php">Generate Question Paper - IX</a>
                                     <a href="hot10.php">Generate Question Paper -  X</a>
                                </li>
                                
                            </ul>
                        

                        <li class="active">
                            <a href="#"> Question Generation CAT 2<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                            <li>
                                    <a class="active" href="quesstep2.php">Reviewed Questions</a>
                                </li>
                                <li>
                                    <a class="active" href="createqp2.php">Add Questions</a>
                                </li>
                                <li>
                                    <a href="hot2.php">Generate Question Paper</a>
                                </li>
                               
                            </ul>
                           

                        <li class="active">
                            <a href="#"> Question Generation ETE<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                            <li>
                                    <a class="active" href="quesstep3.php">Reviewed Questions</a>
                                </li>
                                <li>
                                    <a class="active" href="createqp3.php">Add Questions</a>
                                </li>
                                <li>
                                    <a href="hot3.php">Generate Question Paper</a>
                                </li>
                               
                            </ul>
                            
                      
                            <li>
                            <a href="logout.php"></i>Logout</a>
                        </li>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
                               
             

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                       <h1 class="page-header" align="center">List of Questions</h1>
						
						<?php include('connect.php');
						?>
<html>
<head>
<title> all Articles </title>
<script src="ckeditor/ckeditor.js"></script>
</head>

 <style type="text/css">
    body
  {
    font-family: sans-serif;
    position: absolute;
        margin: 0px;
        width: 100%;
  }
  table
{
width: 90%;
      
}
    table,td
    {
      border: 2px ;

      border-collapse:collapse;
    }
    .header
    {
      background-color:green;
      color: white;
	  text-align: center;
    }
    #content
    {
      font-size: 22px;text-align: center;
    }
    #submit
    {
      margin-left:620px;
    }
   
  
    .container
        {
            width: 480px;
            height:20px;
            border:1px solid black;
            margin-left: 35%;
            margin-top: 10%; 
            background-color:#f0f0f0;
            position: absolute;
			
        }
        .message
        {
            position: absolute;
            margin-left:10px;
            font-size:18px;
            margin-top: 50px;
			text-align: center;
        }
      
        
        #text
    {
        height: 45px;
        width: 53px;
        border:2px solid;
        border-color:solid black;
        border-top-style: 1px;
        border-left-style:  1px;
        border-right-style:  1px;
        font-size:15px;
		text-align: center;
    }
	    #text1
    {
        height: 45px;
        width: 253px;
        border:2px solid;
        border-color:solid black;
        border-top-style: 1px;
        border-left-style:  1px;
        border-right-style:  1px;
        font-size:15px;
		text-align: center;
    }

  </style>


	


<body>


 


<?php
include 'db.php';
if (isset($_POST['activate'])||isset($_POST['deactivate'])) {
	# code...
if(isset($_POST['checkbox'])){
	$checkbox = $_POST['checkbox'];
if(isset($_POST['activate'])?$activate = $_POST["activate"]:$deactivate = $_POST["deactivate"])
$qno= "('" . implode( "','", $checkbox ) . "');" ;
	$query2="UPDATE question_master2 SET final = '".(isset($activate)?'X':'N')."' WHERE qno IN $qno";
	$result2=mysql_query($query2);
	 //echo "<script> alert(' Added');</script>";

	
 }
} 

?>




</head>
<body>




  

<div class="bodyc">
<form name="frmactive" method="post" action="">
<br>
 <div id="container">

 
    <table cellpadding="5px" align="center" >
	
   <tr>

<td class="header"><span id="content">Question ID</span></td>
<td class="header"><span id="content">Course Outcome</span></td>
<td class="header"><span id="content">Course Code</span></td>
<td class="header"><span id="content">Knowledge Level</span></td>
<td class="header"><span id="content">Question</span></td>	
<td class="header"><span id="content">Marks</span></td>
<td class="header"><span id="content">status</span></td>
<td class="header"><span id="content">Select the Question</span></td>

</tr>
  
	<?php
	
  
	$mo=$_POST['mo'];
   
	 $marks=$_POST['marks'];
     $course_code=$_POST['course_code'];
	 $r1='y';
    $query="SELECT * FROM question_master2 WHERE mo='$mo' AND marks='$marks' AND course_code='$course_code' ";
    $result=mysql_query($query);
	while($rows=mysql_fetch_array($result)){
?>
  
<tr>

<td id="text"><?php echo $rows['qno']; ?></td>
<td id="text"><?php echo $rows['mo']; ?></td>
<td id="text"><?php echo $rows['course_code']; ?></td>
<td id="text"><?php echo $rows['kl']; ?></td>
<td id="text1"><?php echo $rows['question']; ?></td>
<td id="text"><?php echo $rows['marks']; ?></td>
<td id="text"><?php echo $rows['r1']; ?></td>
<td id="text"><input name="checkbox[]" type="checkbox" id="checkbox[]" value="<?php echo $rows['qno']; ?>"></td>

</tr>
<?php

//$query5="SELECT * FROM marks2";
//$result5=mysql_query($query5);
//$obtained5=mysql_fetch_array($result5);
//$omarks=$obtained5['marks'];
// $m=0;

// $m+=$marks;
//echo $umarks=$omarks+$marks;
//if ($umarks>50)
 //{
   //  echo "<script> alert('Reached Maximum Marks');</script>";
    // echo "<script> window.location='home.php';</script>";
// }
//$query6="update marks2 set marks='$umarks' where id='1'";
//$result6=mysql_query($query6,$link);
// echo mysql_errno($link) . ": " . mysql_error($link). "\n";
//echo "<script> alert('Total Marks Added : $m');</script>";


}



?>
	
<br>	
	<input type="hidden" name="mo" value="<?php echo "$mo";?>">
    <input type="hidden" name="marks" value="<?php echo "$marks";?>">
  <input type="hidden" name="course_code" value="<?php echo $course_code; ?>">
  <tr><td colspan="5"><input name="activate" type="submit" id="activate" value="ADD"  class="btn btn-success"/></td>
</tr>
</tr>
 </div>
 </form>
 </table>
</body>
</html>
  
 
  

</div>
</div>
<div>

</div>

                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
