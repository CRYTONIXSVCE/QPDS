<style type="text/css">
    body
  {
    font-family: Times New Roman;
   
    position: absolute;
        margin: 0px;
        width: 100%;


  }
  {
 font-size: 40;

  }
  
  table
{
width: 90%;
      
}
 
  
   
     
      
        
        #text2
    {
        height: 55px;
        width: 853px;
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: opx;
        border-left-style:  1px;
        border-right-style:  1px;
        font-size:30px;
         margin-top: :0;
      
		text-align: left;
    }
	      #text1
    {
        height: 85px;
        width: 587px;
       
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: 1px;
        border-left-style:  1px;
        border-right-style:  1px;
        font-size:30px;
       
		text-align: left;
    }

     #text3
    {
        height: 85px;
        width: 187px;
       
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: 1px;
        border-left-style:  1px;
        border-right-style:  1px;
        font-size:30px;
       
		text-align: left;
    }
	
  
  </style>

<?php
include ('db.php');
if(isset($_POST['submit'])){
#$selected_val = $_POST['scn'];  // Storing Selected Value In Variable
#$selected_val1 = $_POST['exam']; 
#$selected_val2 = $_POST['monthyear'];  // Storing Selected Value In Variable
#Storing Selected Value In Variable
#$selected_val7 = $_POST['marks'];
$selected_val8= $_POST['course_code']; // Storing Selected Value In Variable
#$selected_val9 = $_POST['exam']; 

   // Displaying Selected Value

}
?>
 





<?php
	include 'db.php';
	$pageTitle = "View Question Paper";
		?>
	<style>
	@page { margin: 2cm 2cm 2cm 2cm; font-size: 40px,font-family:Times New Roman;} 
	</style>
	

	
	<br><br>
	<div id="qp-content">
	<div align="center">

	

          <td> <img src="img\header.png" ></td>
	  
</table>	
  	
 
<table>
	<tr align="center">
	
	<td>
  	  <b> <font size= '3'> CBCS SCHEME - 2018 </font> </b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="img\usn.png" size="110">


	
	
	</td>
	
</tr>

</table>
  <tr>

  <p align="center"><u><b>Department of Electronics and Communication Engineering </b></u></p>
  </tr>
  <table>
	<tr>
	
	
	<td>Course Code: 18EC53</td>
	<td>Course Title: Principles of Communication Systems</td>
	<td >
            
           		Semester/ Section : V/A & B </td>	
            
        </tr>
        <tr>
	
	
	<td>Date : 07/05/2022 </td>
	<td>Time : 09.30 AM to 11.00 AM</td>
	<td >
            
           		Max.Marks : 30 </td>	
            
        </tr>
 
</td>

</tr>

	


 <div class="bodyc">
<br>
 <div id="container">


    <table  align="center" >
	<tr>
		<td valign="top" colspan="5">
	<b>Instructions: Answer Three Full Questions ,Choosing One Full Question From each Part <br>
	



	</td>
	</tr>


   <tr>

<td class="header"><br><br><b><span id="content">S.No</span></b></td>
<td class="header"><br><br><b><span id="content">KL(s)</span></b></td>
<td class="header"><br><br><b><span id="content">CO(s)</span></b></td>
<td class="header"><br><br><b><span id="content">Question</span></b></td>	
<td class="header"><br><br><b><span id="content">Marks</span></b></td>


</tr>
 

    
	
	
<tr>
		<td align="center" colspan="4"> <b>Part A</b></td></tr>
	<tr>
<td valign="top">


 <?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND co='CO  1' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">1)&nbsp;&nbsp;&nbsp;a&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>
<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' and co='CO  1' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>
<tr>
		<td align="center" colspan="4"> <b>OR</b></td></tr>
	<tr>
<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND co='CO  1' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">2)&nbsp;&nbsp;&nbsp;a&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>
<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND co='CO  1' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>













<tr>
		<td align="center" colspan="4"> <b>Part B</b></td></tr>
	<tr>
<td valign="top">


 <?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND co='CO  2' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">3)&nbsp;&nbsp;&nbsp;a&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>
<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND co='CO  2' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>
<tr>
		<td align="center" colspan="4"> <b>OR</b></td></tr>
	<tr>
<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND co='CO  2' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">4)&nbsp;&nbsp;&nbsp;a&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>
<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND co='CO  2' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>









<tr>
		<td align="center" colspan="4"> <b>Part C</b></td></tr>
	<tr>
<td valign="top">


 <?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND co='CO  3' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">5)&nbsp;&nbsp;&nbsp;a&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>
<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>
<tr>
		<td align="center" colspan="4"> <b>OR</b></td></tr>
	<tr>
<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND co='CO  3' and marks='10' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">6)&nbsp;&nbsp;&nbsp;a&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>
<?php
if(isset($_POST['course_code']))
{
	$i=0;
	$course_code=$_POST['course_code'];
	//echo $course_code;
	 #$marks=$_POST['marks'];
	 $r1='X';
	// $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND final='$r1' AND co='CO  2' and IA='' and marks='4' and qno='595' order by rand() LIMIT 1";
    $result=mysql_query($query);
	//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
	
} 
	while($rows=mysql_fetch_array($result)){
		$i++;
?>

<tr>

<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b&nbsp;&nbsp;&nbsp;</td>
<td class="text3" valign="top"><?php echo $rows['kl']; ?></td>
<td class="text3" valign="top"><?php echo $rows['co']; ?></td>
<td class="text2" valign="top"><?php echo $rows['question']; ?></td>
<td class="text1" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows['marks']; ?></td>



</tr>
<?php
}

?>













</td></tr></table></div>
<div id="editor"></div>

<!--Add External Libraries - JQuery and jspdf 
check out url - https://scotch.io/@nagasaiaytha/generate-pdf-from-html-using-jquery-and-jspdf
-->
<script src="https://code.jquery.com/jquery-1.12.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
  
  

    <script  src="js/index.js"></script>




</body>

</html>
		

	
	</div>
	
	
		
