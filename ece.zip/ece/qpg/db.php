<?php 
$db_user_name="root";
$db_passwd="";
$host="localhost";
$db_name="ece1";
$link = mysql_connect($host,$db_user_name,$db_passwd);
mysql_select_db($db_name, $link);
//echo mysql_errno($link) . ": " . mysql_error($link). "\n";
?>