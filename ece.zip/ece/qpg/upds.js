$('#ok').click(function(){
$('.container').hide();
});
$('#notok').click(function(){
  setTimeout(function(){window.location.href='newview.php'},100);
});