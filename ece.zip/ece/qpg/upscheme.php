<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                 <a class="navbar-brand">SVCS,Bengaluru</a>
            </div>
            <!-- /.navbar-header -->

            
            <!-- /.navbar-top-links -->

                
           
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        
                        <li>
                            <a href="#"></i> Subject Entry<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="syllabusco.php">Insert </a>
                                </li>
                                <li>
                                    <a href="updatesubject.php">Update</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="syupload.php"></i> Syllabus</a>
                        </li>
						<li>
                             <a href="syllabussearch.php"></i> View Syllabus</a>
                        </li>
                        <li>
                            <a href="#"></i> Question Entry<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="question.php">Insert </a>
                                </li>
                                <li>
                                    <a href="updatequestions.php">Update</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
						<li>
                            <a href="#"></i> Review Question<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="reviewer1.php">Reviewer 1  </a>
                                </li>
                                <li>
                                    <a href="reviewer2.php">Reviewer 2 </a>
                                </li>
								<li>
                                    <a href="reviewer3.php">Reviewer 3 </a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                       
                        <li class="active">
                            <a href="#"> Question Paper Generation<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
							<li>
                                    <a class="active" href="quesstep1.php">Reviewed Questions</a>
                                </li>
                                <li>
                                    <a class="active" href="createqp.php">Add Questions</a>
                                </li>
                                <li>
                                    <a href="hot.php">Generate Question Paper</a>
                                </li>
								<li>
                                    <a href="qpupload.php">Question Paper Upload</a>
                                </li>
                            </ul>
							<li>
                            <a href="viewqp.php"></i>Print 	Question Paper</a>
                        </li>
						<li>
                            <a href="Backup.php"></i>Backup</a>
                        </li>
							<li>
                            <a href="logout.php"></i>Logout</a>
                        </li>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
                        
           
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Update the Question Here</h1>
						<?php
$con=mysqli_connect('localhost','root','','com') or die("ERROR");
if(isset($_GET['qno']))
{
	$qno= $_GET['qno'];
}
else
{
	header('allarticlesr1.php?success=0');
}
?>
<html>
<head>
<title> Update Data</title>
<script src="ckeditor/ckeditor.js"></script>
</head>
<body>
<form action="upschemepost.php" method="post">
<textarea  class="ckeditor" name="editor">
<?php $query = mysqli_query($con, "SELECT * FROM question_master2 WHERE qno='$qno'");
$row = mysqli_fetch_array($query);

?>
<?php echo $row['sheme'];?>
</textarea>
<input type="hidden" name="qno" value="<?php echo $qno ?>">
<br>
<button type="submit" align ="center" class="btn btn-success">update</button>
</form>
</body>
</html>



                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
