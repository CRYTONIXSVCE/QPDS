<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                 <a class="navbar-brand">SVCE,Bengaluru</a>
            </div>
            <!-- /.navbar-header -->

            
            <!-- /.navbar-top-links -->

              <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        
                        
                   
                        

                        <li class="active">
                            <a href="#"> Question Generation CAT 2<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                            <li>
                                    <a class="active" href="quesstep2.php">Reviewed Questions</a>
                                </li>
                                
                                <li>
                                    <a href="hot6.php">Generate Question Paper</a>
                                </li>
                               
                            </ul>
                           

                        
                               
                            </ul>
                            
                      
                            <li>
                            <a href="logout.php"></i>Logout</a>
                        </li>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav> 
                      