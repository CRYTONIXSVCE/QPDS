<style type="text/css">
    body
  {
    font-family: sans-serif;
    position: absolute;
        margin: 0px;
        width: 100%;
  }
  table
{
width: 90%;
      
}
 
  
   
     
      
        
        #text2
    {
        height: 55px;
        width: 653px;
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: 1px;
        border-left-style:  1px;
        border-right-style:  1px;
        font-size:15px;
        text-align: center;
    }
          #text1
    {
        height: 75px;
        width: 453px;
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: 1px;
        border-left-style:  1px;
        border-right-style:  1px;
        font-size:15px;
        text-align: center;
    }
    
  
  </style>


 





<?php
    include 'db.php';
    $pageTitle = "View Question Paper";
        ?>
    <style>
    @page { margin: 2cm 2cm 2cm 2cm; } 
    </style>
    
    
 <div class="bodyc">
<br>
 <div id="container">
<h3 align="center"> Couse Code:  <?php

 $course_code=$_POST['course_code'];
 echo "$course_code"?></h3>

    <table  align="center" border="1" >
    

<td class="header"><b><span id="content">S.No</span></b></td>

<td class="header"><b><span id="content">Question</span></b></td>  
 <td class="header"><b><span id="content">Key</span></b></td>  
<td class="header"><b><span id="content">Marks</span></b></td>


</tr>
 
   
    
    
    <?php
if(isset($_POST['course_code']))
{
    $i=0;
    $course_code=$_POST['course_code'];
    //echo $course_code;
     //$marks=$_POST['marks'];
     $r1='x';
    // $mo=$_POST['mo'];
    $query="SELECT  * FROM question_master2 WHERE course_code='$course_code' AND final='$r1' ORDER BY mo";
    $result=mysql_query($query);
    //echo mysql_errno($link) . ": " . mysql_error($link). "\n";
    
} 
    while($rows=mysql_fetch_array($result)){
        $i++;
?>
 
<tr>

<td class="text1" valign="=top"><?php echo $i; ?></td>

<td class="text1"  valign="top"><?php echo $rows['question']; ?></td>
<td class="text2"  valign="top"><?php echo $rows['scheme']; ?></td>
<td class="text1"  valign="top"><?php echo $rows['marks']; ?></td>


</tr>
<?php
}

?>
</form>
</tbody>
</table>
</div>
<div id="editor"></div>

<!--Add External Libraries - JQuery and jspdf 
check out url - https://scotch.io/@nagasaiaytha/generate-pdf-from-html-using-jquery-and-jspdf
-->
<script src="https://code.jquery.com/jquery-1.12.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
  
  

    <script  src="js/index.js"></script>




</body>

</html>
        

    
    </div>