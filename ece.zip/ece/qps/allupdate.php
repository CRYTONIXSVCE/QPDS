<?php 

if(!isset($_SERVER['HTTP_REFERER']))
{
	header('location:index.php');
	exit;
}


?>


<!DOCTYPE html>
<html lang="en">
<style type="text/css">
    body
  {
    font-family: sans-serif;
    position: absolute;
        margin: 0px;
        width: 100%;
  }
  table
{
width: 90%;
      box-shadow: 0 0 15px black;
}
    table,td
    {
      border: 2px solid black;
      border-collapse:collapse;
    }
    .header
    {
      background-color:green;
      color: white;
    }
    #content
    {
      font-size: 22px;text-align: center;
    }
    #submit
    {
      margin-left:620px;
    }
    .hidden
    {
      display: none;
    }
    h1
    {
      text-align: center;
      color: rgb(199,56,27);
    }
    .container
        {
            width: 220px;
            height:30px;
            border:1px solid black;
            margin-left: 35%;
            margin-top: 10%; 
            background-color:#f0f0f0;
            position: absolute;
        }
        .message
        {
            position: absolute;
            margin-left:10px;
            font-size:28px;
            margin-top: 50px;
        }
        #ok
        {
            position: absolute;
            margin-top:105px;
            margin-left:75px;
            width:180px;
            height:30px;
            cursor: pointer;
        }
        #notok
        {
            position: absolute;
            margin-top:105px;
            margin-left:300px;
            width:100px;
            height:30px;
            cursor: pointer;
        }
        h3
        {
         text-align: center;
         color: rgb(215,0,107);
        }
        #text
    {
        height: 55px;
        width: 73px;
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: none;
        border-left-style: none;
        border-right-style: none;
        font-size:15px;
		text-align: center;
    }
	     #text1
    {
        height: 35px;
        width: 893px;
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: none;
        border-left-style: none;
        border-right-style: none;
        font-size:15px;
		text-align: center;
    }
		     #text2
    {
        height: 35px;
        width: 250px;
        border:2px solid;
        border-color:rgb(157,0,0);
        border-top-style: none;
        border-left-style: none;
        border-right-style: none;
        font-size:15px;
		text-align: center;
    }
     select 
    {
      -webkit-appearance: none;
      -moz-appearance: none;
      background: transparent;
      background-image: url("data:image/svg+xml;utf8,<svg fill='black' height='24' viewBox='0 0 24 24' width='26' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/><path d='M0 0h24v24H0z' fill='none'/></svg>");
      background-repeat: no-repeat;
      background-position-x: 100%;
      background-position-y: 10px;
      border:3px solid;
      border-color:rgb(157,0,0);
      border-top-style: none;
      border-left-style: none;
      border-right-style: none;
      height: 40px;
      width: 100px;
      padding: 10px;
      cursor: pointer;
      font-size: 15px;
    }
  </style>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                 <a class="navbar-brand">SVCS,Bengaluru</a>
            </div>
            <!-- /.navbar-header -->

            
            <!-- /.navbar-top-links -->

                
           
               
                       <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        
                       
                        <li>
                             <a href="syllabussearch.php"></i> View Syllabus</a>
                        </li>
                        <li>
                            <a href="#"></i> Question Entry<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="question.php">Insert </a>
                                </li>
                                <li>
                                    <a href="updatequestions.php">Update </a>
                                </li>
                                <li>
                                    <a href="keystep1.php">Key </a>
                                </li>
                                 <li>
                                    <a href="schemestep1.php">Scheme </a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                          <li>
                            <a href="index1.php"></i>Change Password</a>
                        </li>
                            <li>
                            <a href="logout.php"></i>Logout</a>
                        </li>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>    
                   
                                                 
             

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Review Questions Here</h1>
   <?php
$host="localhost"; // Host name
$username="root"; // Mysql username
$password=""; // Mysql password
$db_name="ece1"; // Database name
$tbl_name="question_master2"; // Table name
// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");
$course_code=$_POST['course_code'];
$sql="SELECT * FROM $tbl_name where course_code='$course_code'";
$result=mysql_query($sql);
// Count table rows
$count=mysql_num_rows($result);

?>
<?php
// Check if button name "Submit" is active, do this
if(isset($_POST['Submit']))
{
//$course_code=$_POST['course_code'];
$count=count($_POST["qno"]);
for($i=0;$i<$count;$i++){
$sql1="UPDATE $tbl_name SET kl='" . $_POST['kl'][$i] . "',mo='" . $_POST['mo'][$i] . "',co='" . $_POST['co'][$i] . "', marks='" . $_POST['marks'][$i] . "' WHERE qno ='" . $_POST['qno'][$i] . "'";
$result1=mysql_query($sql1);
}
}

 echo "<span><b>Total No of Questions :</span><span>$count</b></span>";
mysql_close();
?>
<p align="center"><b>Note : Give the Status of the question Like (Y / N) </b></p>
<form name="form1" method="post" action="">

<table width="900" border="0" cellspacing="" cellpadding="">
<tr>
<td class="header"><strong>Q_ID</strong></td>
<td class="header"><strong>Question</strong></td>
<td class="header"><strong>Edit Question</strong></td>
<td class="header"><strong>KL</strong></td>
<td class="header"><strong>CO</strong></td>
<td class="header"><strong>Chapter</strong></td>
<td class="header"><strong>Marks</strong></td>
<td class="header"><strong>IA</strong></td>
<td class="header"><strong>Scheme</strong></td>
<td class="header"><strong>Edit Scheme</strong></td>
<td class="header"><strong>Key</strong></td>
<td class="header"><strong>edit Key</strong></td>
</tr>
<?php
while($rows=mysql_fetch_array($result)){
?>
<tr>
<td align="center">
<input style="border-bottom-color: white;" name="qno[]" type="text" id="text" value="<?php echo $rows['qno']; ?>">
</td>
<td id="text1">
<?php echo $rows['question'];?></td>

</td>
<td align="center"><a href="<?php echo'update1.php?qno='.$rows['qno']?>" class="btn btn-success">Edit</a> </td>

<td align="center">
<input style="border-bottom-color: white;" name="kl[]" type="text" id="text" value="<?php echo $rows['kl']; ?>">
</td>
<td align="center">
<input style="border-bottom-color: white;" name="co[]" type="text" id="text" value="<?php echo $rows['co']; ?>">
</td>
<td align="center">
<input style="border-bottom-color: white;" name="mo[]" type="text" id="text" value="<?php echo $rows['mo']; ?>">
</td>
<td align="center">
<input style="border-bottom-color: white;" name="marks[]" type="text" id="text" value="<?php echo $rows['marks']; ?>">
</td>
<td align="center">
<input style="border-bottom-color: white;" name="IA[]" type="text" id="text" value="<?php echo $rows['IA']; ?>">
</td>
<td id="text1">
<?php echo $rows['scheme'];?></td>

</td>
<td align="center"><a href="<?php echo'upscheme.php?qno='.$rows['qno']?>" class="btn btn-success">Edit</a> </td>
<td id="text1">
<?php echo $rows['key1'];?></td>

</td>
<td align="center"><a href="<?php echo'upkey.php?qno='.$rows['qno']?>" class="btn btn-success">Edit</a> </td>
</tr>

<?php
}
?>
</tr>


</table>
<br>
<input type="hidden" name="course_code" value="<?php echo $course_code; ?>">
<input type="submit" name="Submit" value="Update" class="btn btn-success">

</form>
<br>
<input type="button" onclick="history.go(0)" value="refresh"  class="btn btn-success">
<!-- <a class="btn btn-sucess" href="<?php //echo $_SERVER['SCRIPT_NAME']; ?>">Refresh</a> -->
</div>
<div>