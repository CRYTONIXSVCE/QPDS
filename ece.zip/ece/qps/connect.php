<?php $con=mysqli_connect('localhost','root','','ece1') or die("ERROR");
?>