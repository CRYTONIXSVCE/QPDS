


<form action="updatequestions.php" method="post">
<?php 
$con=mysqli_connect('localhost','root','','ece1') or die("ERROR");
if(isset($_POST['editor']))
{
	$editortext=$_POST['editor'];
	$qno=$_POST['qno'];
	$query=mysqli_query($con,"UPDATE question_master2 SET key1='$editortext' WHERE qno='$qno'");
	//echo $editortext;
	
	if($query)
	{
		  
		echo "<script> alert('Data Stored Successfully');
		window.location.href='updatequestions.php';</script>";
	}
	else
	{
		header('location:updatequestions.php?sucess=0');
	}
}

else
{
	
}


?>
</form>
