<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                 <a class="navbar-brand">Galgotias University</a>
            </div>
<!DOCTYPE html>
<html>
<head>
<title>Change Password</title>

</head>

<body>

	<?php 
		$conn_db = mysql_connect("localhost","root","") or die();
		$sel_db = mysql_select_db("scv",$conn_db) or die();
		if(isset($_POST['re_password']))
		{
		$old_pass=$_POST['old_pass'];
		$new_pass=$_POST['new_pass'];
		$re_pass=$_POST['re_pass'];
		$chg_pwd=mysql_query("select * from qpslogin where id='1'");
		$chg_pwd1=mysql_fetch_array($chg_pwd);
		$data_pwd=$chg_pwd1['password'];
		if($data_pwd==$old_pass){
		if($new_pass==$re_pass){
			$update_pwd=mysql_query("update adminlogin set password='$new_pass' where id='1'");
			echo "<script>alert('Update Sucessfully'); window.location='home.php'</script>";
		}
		else{
			echo "<script>alert('Your new and Retype Password is not match'); window.location='index1.php'</script>";
		}
		}
		else
		{
		echo "<script>alert('Your old password is wrong'); window.location='index1.php'</script>";
		}}
	?>
	 <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <h1 class="page-header">Change Password</h1>
                        <div class="panel-body">
                            <div class="row">
	<form method="post">
		
				<p>Old Password</p>
			<div class="form-group">
                                        
              <input class="form-control" type="password"  name="old_pass" placeholder="Old Password..." value="" required />
                                        
              </div>
					
		
				<p>New Password</p>
			<div class="form-group">
                                        
              <input class="form-control" type="password"  name="new_pass" placeholder="New Password..." value=""  required />
		
                                        
              </div>
			<p>Retype New Password</p>
			<div class="form-group">
                                        
              <input class="form-control" type="password"  name="re_pass" placeholder="Retype New Password..." value="" required />
		
                                        
              </div>
					
			
		
		
			<div align="center">
                                  <input type="submit" value="Reset Password" name="re_password" class="btn btn-success"></button>
                                  <!-- <button type="update" class="btn btn-success">Update</button> -->
                                 
								  
                              </div>
		
	</form>
	
</body>
</div>
                      <!-- /.row -->
                  </div>
                  <!-- /.container-fluid -->
              </div>
              <!-- /#page-wrapper -->

              <!-- /#wrapper -->

              <!-- jQuery -->
              <script src="../vendor/jquery/jquery.min.js"></script>

              <!-- Bootstrap Core JavaScript -->
              <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

              <!-- Metis Menu Plugin JavaScript -->
              <script src="../vendor/metisMenu/metisMenu.min.js"></script>

              <!-- Custom Theme JavaScript -->
              <script src="../dist/js/sb-admin-2.js"></script>

          </body>

          </html>