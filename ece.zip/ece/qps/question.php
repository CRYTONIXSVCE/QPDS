<?php
// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>
 

<?php 
include 'db.php';
    if(isset($_POST['submit']))
    {
        $text = $_POST['editor'];
        $text1 = $_POST['editor1'];
        $text2 = $_POST['editor2'];
        $course_code=$_POST['course_code'];
        
        setcookie('course_code',$course_code);
        $co=$_POST['co'];
        $mo=$_POST['mo'];
        //echo $mo;
        $kl=$_POST['kl'];
        $marks=$_POST['marks'];
        $editor=$_POST['editor'];
        $editor1=$_POST['editor1'];
        $editor2=$_POST['editor2'];
       // $question_number=$_POST['question_number'];
        $editor=preg_replace("/^<p.*?>/","",$editor);
        $editor=preg_replace("|</p>$|","",$editor);
        $editor1=preg_replace("/^<p.*?>/","",$editor1);
        $editor1=preg_replace("|</p>$|","",$editor1);
        $editor2=preg_replace("/^<p.*?>/","",$editor2);
        $editor2=preg_replace("|</p>$|","",$editor2);
        $query="INSERT INTO question_master2 (course_code,mo,kl,co,marks,question,key1,scheme) VALUES ('$course_code','$mo','$kl','$co','$marks','$editor','$editor1','$editor2')";
        $result=mysql_query($query,$link);
        //echo mysql_errno($link) . ": " . mysql_error($link). "\n";
        if($result)
        {
             echo "<script> alert('Data Stored Successfully');</script>";
        }
        else
        {
             echo "<script> alert('Error In Storing the Data');</script>";
        
        
        
    }
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                 <a class="navbar-brand">SVCE,Bengaluru</a>
            </div>
            <!-- /.navbar-header -->

            
            <!-- /.navbar-top-links -->

     
             <!-- Navigation -->
          
                       <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        
                       
                       
                        <li>
                            <a href="#"></i> Question Entry<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="question.php">Insert </a>
                                </li>
                                <li>
                                    <a href="updatequestions.php">Update </a>
                                </li>
                                
                                 
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                          
                            <li>
                            <a href="logout.php"></i>Logout</a>
                        </li>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>    
                       
               
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Question Bank</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <form role="form" method="POST" action="question.php">
           <div class="form-group">
           
                                            
           </div>
        <div class="form-group">
                                        <label>Select the Course Code</label>
                                            <select class="form-control" name="course_code" required="" id="select">
       
  
  <?php 
                                            include 'db.php';
                                            $query="SELECT course_code FROM coursemaster";
                                            $result=mysql_query($query);
                                            while($obtained=mysql_fetch_array($result))
                                               {
                                                   $course_code=$obtained['course_code'];
                                                   echo"<option value='$course_code'>$course_code</option>";
                                               } 
                                               ?>
  </select><br><br>
                                        
                                    </div>
            <div class="form-group">
                                            <label>Selects the Module </label>
                                            <select class="form-control" name="mo" required="">
                                                <option value="">Select the Chapter / Unit </option> 
                                                <option value="Module 1">Module 1</option>
                                                <option value="Module 2">Module 2</option>
                                                <option value="Module 3">Module 3</option>
                                                <option value="Module 4">Module 4</option>
                                                <option value="Module 5">Module 5</option>
                                                <option value="Module 6">Module 6</option>
                                                <option value="Module 7">Module 7</option>
                                                <option value="Module 8">Module 8</option>
                                     
                                              

                                            </select>
                                        </div>
                                         <div class="form-group">
                                            <label>Selects the Knowledge level</label>
                                            <select class="form-control" name="co"  required="">
                                            <option value="">Select the Course Outcome</option> 
                                            <option value="CO  1">CO 1</option>
                                                <option value="CO  2">CO 2</option>   
                                                <option value="CO  3">CO 3</option>
                                                <option value="CO  4">CO 4</option>
                                                 <option value="CO  5">CO 5</option>
                                                <option value="CO  6">CO 6</option>
                                                
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Selects the Knowledge level</label>
                                            <select class="form-control" name="kl"  required="">
                                            <option value="">Select the Knowledge level</option> 
                                            <option value="KL 1">KL 1</option>
                                                <option value="KL 2">KL 2</option>   
                                                <option value="KL 3">KL 3</option>
                                                <option value="KL 4">KL 4</option>
                                                 <option value="KL 5">KL 5</option>
                                                <option value="KL 6">KL 6</option>
                                                
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Enter the Marks for the Current Question</label>
                                            <select class="form-control" name="marks"  required="">
                                            <option value="">Select the Mark</option>
                                                <option>10</option>
                                                <option>15</option>
                                                <option>20</option>
                                                                            
                                            </select>
                                        </div>


                
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Enter the Question ,Key and Scheme Here
                        </div>
                        <!-- .panel-heading -->
                        <div class="panel-body">
                            <div class="panel-group" id="accordion">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Question</a>
                                        </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse in">
                                        <div class="panel-body">
                                        
                                         
                                           <script src="ckeditor/ckeditor.js">
</script>
<body>
<script type="text/javascript">
function submitAction(act)
{
    document.sample.action=act;
    document.sample.submit();
}
</script>


<div>
<html lang="en">
<head>
<meta charset="UTF-8">
<title></title>
<style type="text/css">
    body{
        font-family: Arail, sans-serif;
    }
    /* Formatting search box */
    .search-box{
        width: 960px;
        position: relative;
        display: inline-block;
        font-size: 14px;
        margin-left:0px;
    }
    .search-box input[type="text"]{
        height: 32px;
        padding: 5px 10px;
        border: 1px solid #CCCCCC;
        font-size: 14px;
    }
    .result{
        position: absolute;        
        z-index: 30;
        top: 100%;
        left: 0;
    }
    .search-box input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result p{
        margin: 0;
        padding: 2px 10px;
        background:#D3D3D3;
        border-top: none;
        cursor: pointer;
    }
    .result p:hover{
        background: #A9A9A9;
    }
</style>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript">


$(document).ready(function(){
    $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("back1.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
        $(this).parent(".result").empty();
    });
});
</script>


</head>
<body>
    <div class="search-box">
    
    <p class="help-block">Search the Existing Question Here (Ex:Keyword)</p>
        <input type="text" autocomplete="off" placeholder="Search Question Here..." />
        <div class="result"></div>
    </div>
</body>
</html>
</div>
<p  align="center"> <b>Enter the Question Here</b></p>
<textarea class="ckeditor" required="" name="editor" required=" "></textarea><br>

<!-- <input type="button" value ="Update Questions" class="btn btn-success" onclick="submitAction('up')"> -->
<!-- <button class="btn btn-success"><a href="updatequestions.php" style="color: white;text-decoration: none;">Update Questions</a></button>-->

 

</div>




                                    </div>
                                                                        
                                </div>
                                
                                
                                
                                
                 <!-- /.key -->         
                                
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Key</a>
                                        </h4>
                                    </div>
                                    <div id="collapseTwo" class="panel-collapse collapse">
                                        <div class="panel-body">
                                        <script src="ckeditor/ckeditor.js">
</script>
<body>







<p><b>Enter the Key Here</b></p>


<textarea class="ckeditor" name="editor1" required=""></textarea><br>

</body>


                                        
                    
                        
</div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">Scheme</a>
                                        </h4>
                                    </div>
                                    <div id="collapseThree" class="panel-collapse collapse">
                                        <div class="panel-body">
                                     <script src="ckeditor/ckeditor.js">
</script>





<body>






<p><b>Enter the Scheme Here</b></p>


<textarea class="ckeditor" name="editor2" required=""></textarea><br>

</body>


<input type ="submit" value="submit" align="center" class="btn btn-success" name="submit">
</form>
</div>
                                </div>
                                
                                
                                
                                </div>
                                
                                
                            </div>
                        </div>
                        <!-- .panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
            <!-- /.row -->
            
                <!-- /.col-lg-4 -->
                
            <!-- /.row -->
            <
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
</body>

</html>
