<?php 

echo "<div class='container'>
            <span class='message'> Records Uploaded Sucessfully</span><BR>
            <button id='ok'>Ok</button>
            
   </div>";
    
  
	   ?>